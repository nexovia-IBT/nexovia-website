# Nexovia Blogpost Project

## Bottom Line

This project is the working system for generating Nexovia blog articles, SEO metadata, image briefs, and platform-ready copy that can be pasted into the Nexovia platform and scheduled from there.

## What This Project Does

- Creates Nexovia-style long-form blog articles.
- Produces SEO title, meta description, slug, excerpt, tags, FAQ, and image prompts.
- Keeps articles aligned with the recovered Nexovia content strategy.
- Uses a human approval step before anything is posted or scheduled.
- Supports the existing Nexovia platform workflow, where generated articles are added and scheduled manually.

## Recovered Context

The prior Nexovia work included:

- A Squarespace blog called Recovery Guides / All Articles.
- A content rhythm of roughly two articles per week.
- Search Console work for `nexovia.pro`.
- A sitemap refresh that increased discovered pages from 124 to 154.
- Indexing requests for newer articles.
- A slug cleanup for the May 5 article:
  - Old: `/blog/07tu3lf9zx6xx7vh6c8m2gbdujl5nd`
  - New: `/blog/skin-barrier-compromise-post-procedure-sensitivity`
- Redirect rules for outdated URLs.
- Existing article themes around post-procedure recovery, microneedling, laser aftercare, chemical peels, exosomes, PDRN, NAD+, peptides, skin barrier repair, sensitivity, hydration, and pigmentation.

## How To Use

1. Pick a topic from `reference/30-article-calendar.md`.
2. Use `prompts/nexovia-article-generator.md` to generate the article.
3. Paste the output into `templates/platform-ready-article.md`.
4. Review against `reference/seo-and-safety-checklist.md`.
5. Add the article to the Nexovia platform.
6. Schedule it from the platform.

## Required Output For Every Article

- Article title
- SEO title
- Meta description
- URL slug
- Excerpt
- Target keyword
- Secondary keywords
- Category
- Tags
- Full article body
- FAQ block
- Internal link suggestions
- Hero image prompt
- Optional infographic prompt
- Image alt text
- Claims safety notes

