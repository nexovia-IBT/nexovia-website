# SEO And Safety Checklist

## Before Writing

- Define one target keyword.
- Define search intent: informational, comparison, timeline, checklist, or practitioner education.
- Check whether Nexovia already has a similar article.
- Decide where the article fits in the cluster:
  - Microneedling
  - Laser
  - Chemical peel
  - Barrier repair
  - Ingredients
  - Sensitive skin
  - Practitioner education

## Article Quality

- The first 150 words answer the user query clearly.
- The article gives practical guidance, not generic skincare filler.
- The article includes a timeline, checklist, table, FAQ, or decision guide when useful.
- Nexovia is mentioned naturally as a relevant aftercare option.
- The conclusion gives a clear next step.

## SEO Fields

- SEO title is ideally under 60 characters.
- Meta description is ideally 140 to 160 characters.
- Slug is readable, lowercase, and keyword-rich.
- H1 is unique.
- H2s match search intent.
- FAQ questions match real user questions.
- Image alt text is specific.

## Technical Publishing

- Add article to sitemap through the platform.
- Use readable slug. Never use random IDs.
- Add at least 3 internal links:
  - One to a related procedure guide.
  - One to an ingredient article.
  - One to a product/formula page or recovery score CTA.
- Avoid orphan posts.
- After publishing an important article, inspect URL in Search Console.

## Claims Safety

Flag and rewrite:

- "heals"
- "cures"
- "treats"
- "prevents infection"
- "guarantees"
- "clinically proven" without source
- "reverses damage"
- "medical-grade" unless legally verified

Use safer language:

- "supports"
- "helps support"
- "is designed to"
- "may help"
- "helps reduce the appearance of"
- "talk to your practitioner"

