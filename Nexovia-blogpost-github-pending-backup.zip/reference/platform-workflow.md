# Nexovia Platform Workflow

## Bottom Line

The agent prepares the article package. The user places it into the Nexovia platform and schedules posting directly from there.

## Workflow

1. Choose article topic.
2. Generate article package with:
   - Article body.
   - SEO title.
   - Meta description.
   - Slug.
   - Excerpt.
   - Tags.
   - Image prompts.
   - Alt text.
3. Review claims safety.
4. Add article to Nexovia platform.
5. Add or generate images.
6. Schedule article in the platform.
7. After publishing, confirm:
   - Slug is readable.
   - Article appears in sitemap.
   - Internal links are present.
   - Search Console can inspect the URL.

## Publishing Rules

- Do not publish multiple new articles at once unless there is a deliberate launch reason.
- Recommended cadence: two articles per week.
- Important articles should be submitted through Search Console after publication.
- Avoid random slugs.
- Avoid orphan articles with no internal links.

## Image Rules

- Every article should have a hero image.
- Prefer article-specific image alt text.
- Avoid generic captions like "Make it stand out."
- Avoid misleading before-after images.
- Avoid visuals that imply medical treatment or guaranteed results.

