# Nexovia Image Brief Generator

## Bottom Line

Use this prompt to create image briefs for each article after the article is written.

## Prompt

Create image prompts for a Nexovia blog article.

Brand look:

- Premium clinical skincare.
- Korean beauty science.
- White, silver, soft red, clean glass, serum texture.
- Modern dermatology studio feeling.
- Avoid stock-photo cliches.
- Avoid exaggerated medical visuals.
- Avoid showing needles entering skin unless specifically needed and tasteful.

Article:

- Title:
- Target keyword:
- Main idea:
- Procedure or ingredient:

Return:

1. Hero image prompt.
2. Infographic prompt.
3. Social image prompt.
4. Alt text.
5. Negative prompt.

## Visual Rules

- The image should support the article, not decorate it randomly.
- Prefer skin barrier, serum texture, ingredient science, post-procedure calmness, and clean product-adjacent visuals.
- Do not create misleading before/after images.
- Do not imply guaranteed medical results.

