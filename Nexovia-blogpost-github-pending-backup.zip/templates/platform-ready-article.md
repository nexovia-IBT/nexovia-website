# Article Package

## Platform Fields

Title:

SEO Title:

Meta Description:

Slug:

Excerpt:

Category:

Tags:

Target Keyword:

Secondary Keywords:

## Image Package

Hero Image Prompt:

Hero Image Alt Text:

Infographic Prompt:

Social Image Prompt:

## Article Body

Paste article body here.

## FAQ

Paste FAQ here.

## Internal Links

Paste internal link recommendations here.

## Claims Safety Notes

Paste claims review here.

